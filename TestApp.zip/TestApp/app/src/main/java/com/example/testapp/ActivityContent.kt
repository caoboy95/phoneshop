package com.example.testapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.testapp.data.Student
import kotlinx.android.synthetic.main.activity_content.*

class ActivityContent : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_content)
        var intent=intent
        var student: Student = intent.getSerializableExtra("student") as Student
        txtAge.text=student.age.toString()
        txtName.text=student.name.toString()
        btn_return.setOnClickListener {
            view ->
            intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}