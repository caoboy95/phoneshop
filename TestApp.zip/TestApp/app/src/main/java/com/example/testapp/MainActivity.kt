package com.example.testapp

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.testapp.data.Student
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.Integer.parseInt
import java.lang.NumberFormatException


class MainActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var lv1: ListView
    private lateinit var btn1: Button
    private  var editT: ArrayList<EditText> = ArrayList()
    private  var arrayString: ArrayList<Student> = ArrayList()
    lateinit var studentListViewAdapter: StudentListViewAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        arrayString.add(Student(1,"A",18))
        arrayString.add(Student(2,"B",23))
        arrayString.add(Student(3,"C",24))
        findView()
        btn1.setOnClickListener(this)
//        loadList(arrayString)
    }
    fun findView(){
        lv1= findViewById(R.id.listViewTest)
        btn1=findViewById(R.id.btnAddString)
        editT.add(findViewById(R.id.etxtName))
        editT.add(findViewById(R.id.etxtAge))
    }
    fun loadList(arrayString: ArrayList<Student>){
        studentListViewAdapter= StudentListViewAdapter(this,arrayString)
        lv1.adapter = studentListViewAdapter
        lv1.setOnItemClickListener { parent, view, position, id ->
            val element: Student =
                parent.getItemAtPosition(position) as Student // The item that was clicked
            Toast.makeText(this, ""+element.name, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onClick(v: View?) {
        /*if(v!!.getId()==R.id.btnAddString)
        {
            if(!(editT[0].getText().isNullOrEmpty() && editT[1].getText().isNullOrEmpty())) {
                arrayString.add(
                    Student(
                        arrayString[arrayString.lastIndex].id+1,
                        editT[0].getText().toString(),
                        editT[1].getText().toString().toInt()
                    )
                )
                setOf<String>(arrayString.toString())
                loadList(arrayString)
            }
            editT[0].setText("")
            editT[1].setText("")
        }*/

         //check input
//        if(v!!.getId()==R.id.btnAddString)
//        {
//            var numeric = true
//            try{
//                val num=parseInt(etxtAge.text.toString())
//            }catch (e: NumberFormatException){
//                numeric=false
//            }
//            @CheckInput
//            if(!TextUtils.isEmpty(etxtName.text.toString()) and !TextUtils.isEmpty(etxtAge.text.toString()) and numeric ) {
//                Toast.makeText(this,"ok",Toast.LENGTH_LONG).show()
//                val intent: Intent= Intent(this@MainActivity,ActivityContent::class.java)
//                intent.putExtra("student",Student(arrayString[arrayString.lastIndex].id+1,editT[0].getText().toString(),editT[1].getText().toString().toInt()))
//                startActivity(intent)
//            }else Toast.makeText(this,"Input String",Toast.LENGTH_LONG).show()
//
//        }

    }

}