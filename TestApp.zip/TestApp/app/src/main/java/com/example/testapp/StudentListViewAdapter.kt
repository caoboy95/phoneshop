package com.example.testapp
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.testapp.data.Student

class StudentListViewAdapter(var context: Context,var listStudent: ArrayList<Student>) : BaseAdapter(){

    class ViewHolder(row :View){
        var txtname: TextView
        var txtage: TextView
        init{
            txtname=row.findViewById(R.id.txtName) as TextView
            txtage=row.findViewById(R.id.txtAge) as TextView
        }
    }
    override fun getCount(): Int {
        return listStudent.size
    }

    override fun getItem(position: Int): Student {
        return listStudent[position]
    }

    override fun getItemId(position: Int): Long {
        return listStudent[position].id.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var view: View?
        var viewholder: ViewHolder
        if (convertView == null) {
            var layoutinflater: LayoutInflater = LayoutInflater.from(context)
            view = layoutinflater.inflate(R.layout.student_view, null)
            viewholder = ViewHolder(view)
        } else{
            view = convertView
            viewholder = ViewHolder(view)
        }
        var student:Student =getItem(position)
        viewholder.txtname.text=String.format("Name : %s", student.name)
        viewholder.txtage.text=String.format("Age : %s", student.age)
        return view as View
    }

}