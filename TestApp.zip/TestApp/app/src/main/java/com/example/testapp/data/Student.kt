package com.example.testapp.data
import java.io.Serializable;

data class Student (
    @SerializedName("id")
    var id: Int,
    @SerializedName("name")
    var name: String,
    @SerializedName("age")
    var age: Int
)  : Serializable

annotation class SerializedName(val value: String)
